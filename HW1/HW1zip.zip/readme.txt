To launch the script you need the two different data tables in the same directory as this script.
You then type into the python console :
python knn.py

It will create two different files, one is a CSV file and the other is a result file
based off of the changing hyper parameters.